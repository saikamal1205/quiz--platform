# Quiz Platform with Leaderboard

A full-stack quiz application where users enter a username, answer timed
multiple-choice questions, and see their rank on a live leaderboard.

- **Frontend:** React (React Router, fetch API)
- **Backend:** Node.js + Express
- **Storage:** JSON file-based storage (no database setup required)

## Project Structure

```
quiz-platform/
├── backend/
│   ├── data/
│   │   ├── questions.json      # Quiz questions bank
│   │   └── scores.json         # Leaderboard storage (auto-updated)
│   ├── routes/
│   │   ├── quiz.js             # GET questions, POST submit for grading
│   │   └── leaderboard.js      # GET/POST leaderboard entries
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── Home.js
│   │   │   ├── Quiz.js
│   │   │   └── Leaderboard.js
│   │   ├── App.js
│   │   ├── App.css
│   │   ├── api.js
│   │   ├── index.js
│   │   └── index.css
│   └── package.json
├── .gitignore
└── README.md
```

## Running Locally

### 1. Backend

```bash
cd backend
npm install
npm start
```

The API runs at `http://localhost:5000`.

### 2. Frontend

Open a second terminal:

```bash
cd frontend
npm install
npm start
```

The app opens at `http://localhost:3000` and talks to the backend automatically.

> If you deploy the backend somewhere else, set `REACT_APP_API_URL` in a
> `frontend/.env` file, e.g. `REACT_APP_API_URL=https://your-api.com/api`.

## How Scoring Works

- The frontend never knows the correct answers — only the question text and options are sent to the client.
- When the quiz ends, selected answers are POSTed to `/api/questions/submit`, and the server calculates the score.
- The verified score is then saved to `/api/leaderboard`, which persists to `backend/data/scores.json`.

## Pushing This Project to GitHub

1. **Create a new repository** on GitHub (don't initialize it with a README, since you already have one).
2. Open a terminal in the unzipped `quiz-platform` folder and run:

   ```bash
   git init
   git add .
   git commit -m "Initial commit: full-stack quiz platform with leaderboard"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   git push -u origin main
   ```

3. Replace `<your-username>` and `<your-repo-name>` with your actual GitHub username and the repository name you created.
4. If prompted for credentials, use a [GitHub Personal Access Token](https://github.com/settings/tokens) instead of your password (GitHub no longer accepts password auth over HTTPS).

### Updating the repo later

```bash
git add .
git commit -m "Describe your change"
git push
```

## Notes for Your Resume / Portfolio

- Mention this as: *"Built a full-stack quiz platform with a live leaderboard using React and Node/Express, with server-side answer validation to prevent score tampering."*
- Consider deploying the backend on Render/Railway and the frontend on Vercel/Netlify for a live demo link — that link on your resume matters a lot to recruiters.
