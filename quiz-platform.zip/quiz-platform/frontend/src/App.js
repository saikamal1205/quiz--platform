import React, { useState } from "react";
import { Routes, Route, Link, useNavigate } from "react-router-dom";
import Home from "./components/Home";
import Quiz from "./components/Quiz";
import Leaderboard from "./components/Leaderboard";
import "./App.css";

function App() {
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  const handleStart = (name) => {
    setUsername(name);
    navigate("/quiz");
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <Link to="/" className="brand">
          🧠 QuizPlatform
        </Link>
        <nav>
          <Link to="/">Home</Link>
          <Link to="/leaderboard">Leaderboard</Link>
        </nav>
      </header>

      <main className="app-main">
        <Routes>
          <Route path="/" element={<Home onStart={handleStart} />} />
          <Route path="/quiz" element={<Quiz username={username} />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
        </Routes>
      </main>

      <footer className="app-footer">Built with React & Node/Express</footer>
    </div>
  );
}

export default App;
