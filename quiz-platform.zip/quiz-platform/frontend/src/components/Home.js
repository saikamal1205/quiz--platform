import React, { useState } from "react";

function Home({ onStart }) {
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError("Please enter a username to continue.");
      return;
    }
    onStart(trimmed);
  };

  return (
    <div className="card home-card">
      <h1>Test your knowledge</h1>
      <p className="subtitle">
        Answer 10 quick questions and see how you rank on the live leaderboard.
      </p>
      <form onSubmit={handleSubmit} className="home-form">
        <input
          type="text"
          placeholder="Enter your username"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            setError("");
          }}
          maxLength={30}
        />
        <button type="submit">Start Quiz</button>
      </form>
      {error && <p className="error-text">{error}</p>}
    </div>
  );
}

export default Home;
