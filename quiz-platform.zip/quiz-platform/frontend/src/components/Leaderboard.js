import React, { useEffect, useState } from "react";
import { fetchLeaderboard } from "../api";

function Leaderboard() {
  const [scores, setScores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchLeaderboard()
      .then((data) => {
        setScores(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return (
    <div className="card leaderboard-card">
      <h2>🏆 Leaderboard</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error-text">{error}</p>}
      {!loading && !error && scores.length === 0 && <p>No scores yet. Be the first!</p>}
      {!loading && scores.length > 0 && (
        <table className="leaderboard-table">
          <thead>
            <tr>
              <th>Rank</th>
              <th>Username</th>
              <th>Score</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {scores.map((entry, idx) => (
              <tr key={entry.id}>
                <td>{idx + 1}</td>
                <td>{entry.username}</td>
                <td>
                  {entry.score} / {entry.total}
                </td>
                <td>{entry.timeTakenSeconds}s</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default Leaderboard;
