import React, { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { fetchQuestions, submitAnswers, postScore } from "../api";

const SECONDS_PER_QUESTION = 15;

function Quiz({ username }) {
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState([]); // { id, selectedIndex }
  const [timeLeft, setTimeLeft] = useState(SECONDS_PER_QUESTION);
  const [startTime] = useState(Date.now());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Redirect back to Home if someone lands here without a username
  useEffect(() => {
    if (!username) {
      navigate("/");
    }
  }, [username, navigate]);

  useEffect(() => {
    fetchQuestions()
      .then((data) => {
        setQuestions(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const goToNext = useCallback(
    (selectedIndex) => {
      setAnswers((prev) => {
        const question = questions[currentIndex];
        const updated = [...prev, { id: question.id, selectedIndex }];
        return updated;
      });
      setTimeLeft(SECONDS_PER_QUESTION);
      setCurrentIndex((prev) => prev + 1);
    },
    [currentIndex, questions]
  );

  // Timer countdown; auto-advances with no selection (-1) when it hits 0
  useEffect(() => {
    if (loading || result || questions.length === 0) return undefined;
    if (currentIndex >= questions.length) return undefined;

    if (timeLeft === 0) {
      goToNext(-1);
      return undefined;
    }

    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, loading, result, questions.length, currentIndex, goToNext]);

  // Once all questions are answered, submit for grading + save to leaderboard
  useEffect(() => {
    if (questions.length > 0 && currentIndex >= questions.length && !result && !submitting) {
      setSubmitting(true);
      const timeTakenSeconds = Math.round((Date.now() - startTime) / 1000);

      submitAnswers(answers)
        .then((graded) => {
          setResult(graded);
          return postScore({
            username,
            score: graded.score,
            total: graded.total,
            timeTakenSeconds,
          });
        })
        .catch((err) => setError(err.message))
        .finally(() => setSubmitting(false));
    }
  }, [currentIndex, questions.length, answers, result, submitting, username, startTime]);

  if (!username) return null;
  if (loading) return <div className="card">Loading questions...</div>;
  if (error) return <div className="card error-text">{error}</div>;

  if (result) {
    return (
      <div className="card result-card">
        <h2>Quiz Complete!</h2>
        <p className="score-display">
          {result.score} / {result.total}
        </p>
        <p>Great job, {username}! Your score has been saved to the leaderboard.</p>
        <button onClick={() => navigate("/leaderboard")}>View Leaderboard</button>
      </div>
    );
  }

  const question = questions[currentIndex];
  if (!question) return <div className="card">Preparing results...</div>;

  return (
    <div className="card quiz-card">
      <div className="quiz-meta">
        <span>
          Question {currentIndex + 1} / {questions.length}
        </span>
        <span className={`timer ${timeLeft <= 5 ? "timer-warning" : ""}`}>⏱ {timeLeft}s</span>
      </div>
      <h2>{question.question}</h2>
      <div className="options">
        {question.options.map((option, idx) => (
          <button key={idx} className="option-btn" onClick={() => goToNext(idx)}>
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

export default Quiz;
