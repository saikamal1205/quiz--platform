const API_BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

async function handleResponse(res) {
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed with status ${res.status}`);
  }
  return res.json();
}

export async function fetchQuestions() {
  const res = await fetch(`${API_BASE_URL}/questions`);
  return handleResponse(res);
}

export async function submitAnswers(answers) {
  const res = await fetch(`${API_BASE_URL}/questions/submit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ answers }),
  });
  return handleResponse(res);
}

export async function fetchLeaderboard() {
  const res = await fetch(`${API_BASE_URL}/leaderboard`);
  return handleResponse(res);
}

export async function postScore({ username, score, total, timeTakenSeconds }) {
  const res = await fetch(`${API_BASE_URL}/leaderboard`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, score, total, timeTakenSeconds }),
  });
  return handleResponse(res);
}
