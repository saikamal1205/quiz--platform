const express = require("express");
const cors = require("cors");

const quizRoutes = require("./routes/quiz");
const leaderboardRoutes = require("./routes/leaderboard");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Quiz Platform API is running" });
});

app.use("/api/questions", quizRoutes);
app.use("/api/leaderboard", leaderboardRoutes);

app.listen(PORT, () => {
  console.log(`Quiz Platform API listening on port ${PORT}`);
});
