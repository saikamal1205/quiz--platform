const express = require("express");
const path = require("path");
const fs = require("fs");

const router = express.Router();
const SCORES_PATH = path.join(__dirname, "..", "data", "scores.json");

function loadScores() {
  if (!fs.existsSync(SCORES_PATH)) return [];
  const raw = fs.readFileSync(SCORES_PATH, "utf-8");
  return raw.trim() ? JSON.parse(raw) : [];
}

function saveScores(scores) {
  fs.writeFileSync(SCORES_PATH, JSON.stringify(scores, null, 2));
}

// GET /api/leaderboard -> top 10 scores, highest first, ties broken by fastest time
router.get("/", (req, res) => {
  try {
    const scores = loadScores();
    const top = [...scores]
      .sort((a, b) => b.score - a.score || a.timeTakenSeconds - b.timeTakenSeconds)
      .slice(0, 10);
    res.json(top);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load leaderboard" });
  }
});

// POST /api/leaderboard -> body: { username, score, total, timeTakenSeconds }
router.post("/", (req, res) => {
  try {
    const { username, score, total, timeTakenSeconds } = req.body;

    if (!username || typeof score !== "number" || typeof total !== "number") {
      return res.status(400).json({ error: "username, score, and total are required" });
    }

    const entry = {
      id: Date.now().toString(),
      username: String(username).slice(0, 30),
      score,
      total,
      timeTakenSeconds: typeof timeTakenSeconds === "number" ? timeTakenSeconds : 0,
      createdAt: new Date().toISOString(),
    };

    const scores = loadScores();
    scores.push(entry);
    saveScores(scores);

    res.status(201).json(entry);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to save score" });
  }
});

module.exports = router;
