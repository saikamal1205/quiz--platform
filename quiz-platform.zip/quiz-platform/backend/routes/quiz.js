const express = require("express");
const path = require("path");
const fs = require("fs");

const router = express.Router();
const QUESTIONS_PATH = path.join(__dirname, "..", "data", "questions.json");

function loadQuestions() {
  const raw = fs.readFileSync(QUESTIONS_PATH, "utf-8");
  return JSON.parse(raw);
}

// GET /api/questions -> returns questions WITHOUT correct answers (so the client can't cheat)
router.get("/", (req, res) => {
  try {
    const questions = loadQuestions();
    const safeQuestions = questions.map(({ id, question, options }) => ({
      id,
      question,
      options,
    }));
    res.json(safeQuestions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load questions" });
  }
});

// POST /api/questions/submit -> body: { answers: [{ id, selectedIndex }] }
// Returns the score, calculated server-side so results can't be spoofed.
router.post("/submit", (req, res) => {
  try {
    const { answers } = req.body;
    if (!Array.isArray(answers)) {
      return res.status(400).json({ error: "answers must be an array" });
    }

    const questions = loadQuestions();
    const questionMap = new Map(questions.map((q) => [q.id, q]));

    let score = 0;
    const results = answers.map(({ id, selectedIndex }) => {
      const question = questionMap.get(id);
      const isCorrect = question && question.correctIndex === selectedIndex;
      if (isCorrect) score += 1;
      return {
        id,
        selectedIndex,
        correctIndex: question ? question.correctIndex : null,
        isCorrect: Boolean(isCorrect),
      };
    });

    res.json({ score, total: questions.length, results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to grade quiz" });
  }
});

module.exports = router;
